package com.dicoding.basicfree.recipenotes.adapter;

import com.dicoding.basicfree.recipenotes.model.Datas;

public interface OnItemClickCallback
{
    void onItemClicked(Datas data);
}
