package com.example.prototype.mymoviecataloguemade1.movie

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.prototype.mymoviecataloguemade1.R

class MovieAdapter internal constructor(private val context: Context): BaseAdapter() {
    internal var movies = arrayListOf<Movie>()

    override fun getView(position: Int, view: View?, viewGroup: ViewGroup?): View {
        var itemView = view
        if(itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.movie_item, viewGroup, false)
        }
        val viewHolder = ViewHolder(itemView as View)
        val movie = getItem(position) as Movie
        viewHolder.bind(movie)
        return itemView
    }

    override fun getItem(p0: Int): Any {
        return movies[p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getCount(): Int {
        return movies.size
    }

    private inner class ViewHolder internal constructor(view: View) {
        private val textTitle: TextView = view.findViewById(R.id.txt_title)
        private val textDesc: TextView = view.findViewById(R.id.txt_desc)
        private val textInfo: TextView = view.findViewById(R.id.txt_info)
        private val imgPhoto: ImageView = view.findViewById(R.id.img_photo)

        internal fun bind (movie: Movie) {
            textTitle.text = movie.title
            textDesc.text = movie.description
            textInfo.text = (movie.rating + " | " + movie.release)
            imgPhoto.setImageResource(movie.photo)

        }
    }
}
