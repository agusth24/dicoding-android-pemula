package com.example.prototype.mymoviecataloguemade3.ui.movies

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.example.prototype.mymoviecataloguemade3.R
import kotlinx.android.synthetic.main.item_row_movies.view.*
import java.math.RoundingMode


class MoviesAdapter : RecyclerView.Adapter<MoviesAdapter.MovieViewHolder>() {
    private val mData = ArrayList<Movies>()
    private var onItemClickCallback: OnItemClickCallback? = null

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }
    fun setData(items: ArrayList<Movies>) {
        mData.clear()
        mData.addAll(items)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(
        viewGroup: ViewGroup,
        position: Int
    ): MovieViewHolder {
        val mView = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_row_movies, viewGroup, false)
        return MovieViewHolder(mView)
    }

    override fun getItemCount(): Int = mData.size

    override fun onBindViewHolder(movieViewHolder: MovieViewHolder, position: Int) {
        movieViewHolder.bind(mData[position])
    }

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(movie: Movies) {
            with(itemView) {
                val overview = if(movie.description.toString().isEmpty()) {
                    resources.getString(R.string.no_desc)
                } else {
                    movie.description
                }

                Glide.with(itemView.context)
                    .load("https://image.tmdb.org/t/p/w185/" + movie.photo)
                    .apply(RequestOptions().transform(RoundedCorners(16)))
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .into(img_movie_item_photo)
                tv_movie_item_title.text = movie.title
                tv_movie_item_description.text = overview
                val rating = movie.rating.toDouble()
                val rounded = rating.toBigDecimal().setScale(1, RoundingMode.UP).toDouble()
                tv_movie_item_information.text = rounded.toString() + " | " + movie.release

                itemView.setOnClickListener { onItemClickCallback?.onItemClicked(movie)}
            }
        }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Movies)
    }
}

